#include "../include/GetCandidate.h"
#include <stdio.h>
GetCandidate::GetCandidate()
{}

GetCandidate::~GetCandidate()
{}

vector<Candidate> GetCandidate::run(Mat &Image)
{
	printf("get GetCandidate\n");

	Candidate cd;
	cd.max_i=0;

	ccStore.push_back(cd);

	return ccStore;
}
