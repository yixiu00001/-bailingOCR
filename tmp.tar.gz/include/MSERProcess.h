/*=============================================================================
#
# Author: yixiu - yixiu@inspur.com
#
# Technique Research Centre
#
# Last modified: 2016-11-01 9:30
#
# Filename: mser.h
#
# Description:�ṩͼ��ʶ��Ľӿ�
#
=============================================================================*/
#ifndef _MSER_
#define _MSER_
#include "head.h"
#include "DealCorrect.h"
#include "GetCandidate.h"
#include<climits>
using namespace cv;
using namespace std;
class MSERProcess
{
	public:
		MSERProcess(char* path);
		MSERProcess();
		~MSERProcess();

		//char *process(char*, int);
		char* doGetText(Mat src);
	private:
		//Mat FilterAdaptive(Mat &src);
		//void showWindowImg(string, Mat &);
		//void showMserRes(Mat &src, vector<Candidate> candidateStore);
		//char* dealSpace(char* source);
	private:
		DealCorrect *dealCorrect;
		GetCandidate * getCandidate;
	private:
		char path[INT_MAX];
		vector<Candidate>candidateStore;
};		
#endif
