#ifndef _HEAD_
#define _HEAD_
#include "opencv2/opencv.hpp"
#include "opencv2/highgui/highgui.hpp"
#include "opencv2/features2d/features2d.hpp"
#include "opencv2/imgproc/imgproc.hpp"
#include "opencv2/objdetect/objdetect.hpp"

//#include "GetCandidate.h"
//#include "LinkCandidate.h"
//#include "DealCorrect.h"
//#include "textRecognition.h"

#include <iostream>
#include <vector>
#include <cmath>
#include <string>  
#include <sstream> 

#endif
