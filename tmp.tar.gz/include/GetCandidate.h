#ifndef _GET_CANDIDATE_
#define _GET_CANDIDATE_
#include "head.h"
#include<vector>
#include "Candidate.h"
#include <math.h>

using namespace std;
using namespace cv;
class GetCandidate
{
public:
	GetCandidate();
	~GetCandidate();
	vector<Candidate> run(Mat &Image);
	
private:
	MSER mser;
	vector<Candidate>ccStore;
};

#endif
